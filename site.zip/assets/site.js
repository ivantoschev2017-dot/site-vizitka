
(() => {
  const qs = (s, root=document) => root.querySelector(s);
  const qsa = (s, root=document) => Array.from(root.querySelectorAll(s));

  // Reveal animations
  const reveal = qsa('[data-reveal="true"]');
  if ('IntersectionObserver' in window) {
    const io = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.08, rootMargin: '0px 0px -4% 0px' });
    reveal.forEach(el => io.observe(el));
  } else {
    reveal.forEach(el => el.classList.add('is-visible'));
  }

  // All CTA buttons without a href scroll to the calculator/contact section.
  qsa('button.button').forEach((btn) => {
    const text = btn.textContent.trim().toLowerCase();
    if (text.includes('обсудить проект') || text.includes('получить консультацию')) {
      btn.addEventListener('click', () => {
        (qs('#calculator') || qs('#contacts'))?.scrollIntoView({behavior:'smooth', block:'start'});
      });
    }
  });

  // Mobile menu
  const menuButton = qs('.menu-button');
  if (menuButton) {
    const menu = document.createElement('div');
    menu.className = 'static-mobile-menu';
    menu.innerHTML = `
      <div class="static-mobile-menu__panel">
        <div class="static-mobile-menu__top">
          <span>Меню</span>
          <button type="button" class="static-mobile-menu__close" aria-label="Закрыть меню">×</button>
        </div>
        <nav>
          <a href="#formats">Решения</a>
          <a href="#projects">Проекты</a>
          <a href="#life">Жизнь Контура</a>
          <a href="#process">Как работаем</a>
          <a href="#faq">Вопросы</a>
          <a href="#contacts">Контакты</a>
        </nav>
        <a class="button button--accent button--wide" href="tel:+79673358990">+7 967 335-89-90</a>
      </div>`;
    document.body.appendChild(menu);
    const close = () => {
      menu.classList.remove('is-open');
      menuButton.setAttribute('aria-expanded','false');
      document.body.classList.remove('menu-open');
    };
    menuButton.addEventListener('click', () => {
      menu.classList.add('is-open');
      menuButton.setAttribute('aria-expanded','true');
      document.body.classList.add('menu-open');
    });
    qs('.static-mobile-menu__close', menu)?.addEventListener('click', close);
    menu.addEventListener('click', e => { if (e.target === menu) close(); });
    qsa('a', menu).forEach(a => a.addEventListener('click', close));
  }

  // FAQ accordion (the saved page contains the exact questions; answers are embedded in HTML).
  qsa('#faq [data-slot="accordion-item"]').forEach((item) => {
    const trigger = qs('[data-slot="accordion-trigger"]', item);
    const content = qs('[data-slot="accordion-content"]', item);
    if (!trigger || !content) return;
    trigger.addEventListener('click', () => {
      const willOpen = trigger.getAttribute('aria-expanded') !== 'true';
      qsa('#faq [data-slot="accordion-item"]').forEach(other => {
        const t = qs('[data-slot="accordion-trigger"]', other);
        const c = qs('[data-slot="accordion-content"]', other);
        if (!t || !c || other === item) return;
        t.setAttribute('aria-expanded','false');
        t.dataset.state='closed';
        other.dataset.state='closed';
        c.dataset.state='closed';
        c.hidden = true;
      });
      trigger.setAttribute('aria-expanded', String(willOpen));
      trigger.dataset.state = willOpen ? 'open' : 'closed';
      item.dataset.state = willOpen ? 'open' : 'closed';
      content.dataset.state = willOpen ? 'open' : 'closed';
      content.hidden = !willOpen;
    });
  });

  // Calculator/brief
  const calculator = qs('#calculator');
  if (calculator) {
    const objectButtons = qsa('.segmented button', calculator);
    const formatButtons = qsa('.brief-formats button', calculator);
    const output = qs('.range-control output', calculator);
    const slider = qs('#area-slider', calculator);
    const sliderTrack = qs('[data-slot="slider-track"]', calculator);
    const sliderRange = qs('[data-slot="slider-range"]', calculator);
    const sliderThumbWrap = slider?.querySelector('[data-slot="slider-thumb"]')?.parentElement || null;
    const sliderThumb = qs('[data-slot="slider-thumb"]', calculator);
    const resultValues = qsa('.brief__plan strong', calculator);
    const telegram = qs('.brief__result a[href*="t.me/"]', calculator);

    let objectType = (qs('.segmented .is-active', calculator)?.textContent || 'Квартира').trim();
    let format = (qs('.brief-formats .is-active', calculator)?.textContent || 'Комфорт плюс').trim();
    let area = parseInt((output?.textContent || '70').replace(/\D/g,''),10) || 70;

    const setActive = (buttons, active) => buttons.forEach(btn => {
      const on = btn === active;
      btn.classList.toggle('is-active', on);
      btn.setAttribute('aria-pressed', String(on));
    });

    const durationFor = (a) => {
      if (a <= 45) return 'от 2 месяцев';
      if (a <= 90) return 'от 3 месяцев';
      if (a <= 140) return 'от 4 месяцев';
      return 'от 5 месяцев';
    };

    const updateSliderVisual = () => {
      const pct = ((area - 20) / 230) * 100;
      if (output) output.textContent = `${area} м²`;
      if (sliderRange) {
        sliderRange.style.left = '0%';
        sliderRange.style.right = `${100-pct}%`;
      }
      if (sliderThumbWrap) sliderThumbWrap.style.left = `calc(${pct}% + ${(0.5-pct/100)*16}px)`;
      if (sliderThumb) sliderThumb.setAttribute('aria-valuenow', String(area));
    };

    const updateResult = () => {
      if (resultValues[0]) resultValues[0].textContent = objectType;
      if (resultValues[1]) resultValues[1].textContent = `${area} м²`;
      if (resultValues[2]) resultValues[2].textContent = format;
      if (resultValues[3]) resultValues[3].textContent = durationFor(area);
      if (telegram) {
        const message = `Здравствуйте! Хочу обсудить ремонт.\nОбъект: ${objectType}\nПлощадь: ${area} м²\nФормат: ${format}`;
        telegram.href = `https://t.me/artemkontur?text=${encodeURIComponent(message)}`;
      }
    };

    objectButtons.forEach(btn => btn.addEventListener('click', () => {
      objectType = btn.textContent.trim();
      setActive(objectButtons, btn);
      updateResult();
    }));
    formatButtons.forEach(btn => btn.addEventListener('click', () => {
      format = btn.textContent.trim();
      setActive(formatButtons, btn);
      updateResult();
    }));

    const setAreaFromPointer = (clientX) => {
      if (!sliderTrack) return;
      const r = sliderTrack.getBoundingClientRect();
      const t = Math.max(0, Math.min(1, (clientX-r.left)/r.width));
      area = Math.round((20 + t*230) / 5) * 5;
      area = Math.max(20, Math.min(250, area));
      updateSliderVisual();
      updateResult();
    };
    slider?.addEventListener('pointerdown', e => {
      setAreaFromPointer(e.clientX);
      slider.setPointerCapture?.(e.pointerId);
      const move = ev => setAreaFromPointer(ev.clientX);
      const up = ev => {
        slider.removeEventListener('pointermove', move);
        slider.removeEventListener('pointerup', up);
        slider.releasePointerCapture?.(ev.pointerId);
      };
      slider.addEventListener('pointermove', move);
      slider.addEventListener('pointerup', up);
    });
    sliderThumb?.addEventListener('keydown', e => {
      if (!['ArrowLeft','ArrowRight','ArrowDown','ArrowUp','Home','End'].includes(e.key)) return;
      e.preventDefault();
      if (e.key === 'Home') area = 20;
      else if (e.key === 'End') area = 250;
      else if (e.key === 'ArrowLeft' || e.key === 'ArrowDown') area = Math.max(20, area-5);
      else area = Math.min(250, area+5);
      updateSliderVisual(); updateResult();
    });
    updateSliderVisual(); updateResult();
  }

  // Project cards: open a local lightbox.
  const projectCards = qsa('[data-project-card="true"]');
  if (projectCards.length) {
    const modal = document.createElement('div');
    modal.className = 'project-lightbox';
    modal.innerHTML = `
      <div class="project-lightbox__box" role="dialog" aria-modal="true" aria-label="Проект">
        <button type="button" class="project-lightbox__close" aria-label="Закрыть">×</button>
        <img alt="">
        <div class="project-lightbox__copy">
          <h3></h3>
          <p></p>
          <a class="button button--accent" href="#contacts">Обсудить похожий проект</a>
        </div>
      </div>`;
    document.body.appendChild(modal);
    const closeModal = () => modal.classList.remove('is-open');
    qs('.project-lightbox__close', modal)?.addEventListener('click', closeModal);
    modal.addEventListener('click', e => { if (e.target === modal) closeModal(); });
    document.addEventListener('keydown', e => { if (e.key === 'Escape') closeModal(); });
    qs('a[href="#contacts"]', modal)?.addEventListener('click', closeModal);

    projectCards.forEach(card => card.addEventListener('click', e => {
      e.preventDefault();
      const img = qs('img', card);
      const title = qsa('h3,h4,strong', card).map(x=>x.textContent.trim()).find(Boolean) ||
                    card.textContent.trim().split(/\s{2,}/).pop() || 'Проект «Контур»';
      const text = card.textContent.replace(/\s+/g,' ').trim();
      const modalImg = qs('img', modal);
      modalImg.src = img?.src || '';
      modalImg.alt = img?.alt || title;
      qs('h3', modal).textContent = title;
      qs('.project-lightbox__copy p', modal).textContent = text;
      modal.classList.add('is-open');
    }));
  }

  // Ensure internal anchors use smooth scrolling and don't leave the site.
  qsa('a[href^="#"]').forEach(a => a.addEventListener('click', (e) => {
    const id = a.getAttribute('href');
    if (!id || id === '#') return;
    const target = qs(id);
    if (target) {
      e.preventDefault();
      target.scrollIntoView({behavior:'smooth', block:'start'});
      history.replaceState(null,'',id);
    }
  }));
})();
